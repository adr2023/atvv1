let a=parseFloat(prompt('digite o valor em reais'));
let dolar=5.80;
let valor=(a/dolar);
alert('valor em dolar='+valor)
