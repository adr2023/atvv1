  let a=parseFloat(prompt('1°'))
  let b=parseFloat(prompt('2°'))
 let soma=a+b;
 if(soma>20){
    alert(soma+8)
    
 }else{
    alert(soma-5)
 }