let a=parseFloat(prompt('valor1:'))
let b=parseFloat(prompt('valor2:'))
   let produto=a*b;

let saldo=(produto*0.33)
let total=(a+saldo);
  alert('valor com 33% a mais='+total)