let a=parseFloat(prompt('produto:'))
  let valor1=a*0.45;
  let valor2=a*0.30;
if(a>20){
    alert(a+valor1)
}else{
  alert(a+valor2)
}