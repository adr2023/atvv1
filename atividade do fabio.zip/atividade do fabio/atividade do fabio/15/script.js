let a=parseFloat(prompt('digite a idade:'))
 
if(a>=18){
    alert('adulto')
}else if(a>=14){
    alert('juvenil')
}else if(   a>=9){
    alert('infantil')
}else if(a<9){
   alert('mirim')
}